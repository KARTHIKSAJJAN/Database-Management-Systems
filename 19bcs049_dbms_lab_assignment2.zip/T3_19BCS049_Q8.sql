CREATE TABLE new_CustomerDetails
(
	customer_id CHAR(10) PRIMARY KEY NOT NULL,
	first_name VARCHAR(20) NOT NULL, 
	last_name VARCHAR(20) NOT NULL,
	dateOfBirth DATE NOT NULL,
	age AS DATEDIFF(YEAR, dateOfBirth, GETDATE()),
	gender CHAR(1) NOT NULL,
	phone VARCHAR(12) NOT NULL,
	address TEXT NOT NULL 
);